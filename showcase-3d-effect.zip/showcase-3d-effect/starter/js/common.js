document.addEventListener('DOMContentLoaded', function() {

	// $('body').hide()

})
